import React from 'react';
import './collapse.css'

// import { Container } from './styles';


/* OS LINKS ABAIXO DEVER SER INCLUÍDOS NO HEAD DO HTML */


{/* <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> */}

/* --------------------------------------------------------------- */

function Componentes() {
    return <div>






        <h1 className="text-center">Team Design Section with Pure CSS Effect</h1>


        <div className="container">
            <div className="row">


                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/9c27b0/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/336699/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/607d8b/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/4caf50/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/e91e63/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>

                <div className="col-lg-4">
                    <div className="our-team-main">

                        <div className="team-front">
                            <img src="http://placehold.it/110x110/2196f3/fff?text=Dilip" className="img-fluid" />
                            <h3>Dilip Kevat</h3>
                            <p>Web Designer</p>
                        </div>

                        <div className="team-back">
                            <span>
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque penatibus et magnis dis parturient montes,
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                                natoque.
</span>
                        </div>

                    </div>
                </div>




            </div>
        </div>
    </div>;
}

export default Componentes;