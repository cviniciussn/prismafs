import React from 'react'
import img1 from '../img/Picture1.png'
import img2 from '../img/Picture2.gif'
import img3 from '../img/Picture3.png'
import img4 from '../img/Picture4.gif'
import img5 from '../img/Picture5.png'
import img6 from '../img/Picture6.gif'
import img7 from '../img/Picture7.gif'
import img8 from '../img/Picture8.png'


export default function comp5() {
    return (

<div style={{maxWidth: "1000px"}}>
<div class="how-section1">
                    <div class="row">
                        <div class="col-md-6 how-img ">
                            <img src={img1} class="rounded-circle img-fluid" alt=""/>
                        </div>
                        <div class="col-md-6 box8 ">
                            <h4>PERMISSÃO DE TRABALHO</h4>
                                        <h4 class="subheading ">
                                        Documento utilizado para avaliar e aprovar a realização das seguintes atividades: trabalho em altura, com químicos, içamento de carga/escavações, a quente e com risco.

                                        </h4>
                        <p class="text-muted"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 box8">
                            <h4>Get hired quickly</h4>
                                        <h4 class="subheading"></h4>
                        </div>
                        <div class="col-md-6 how-img">
                            <img src={img2} class="rounded-circle img-fluid" alt=""/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6  how-img">
                             <img src={img3} class="rounded-circle img-fluid" alt=""/>
                        </div>
                        <div class="col-md-6 box8">
                            <h4>Work efficiently, effectively.</h4>
                                        <h4 class="subheading">With GetLance, you have the freedom and flexibility to control when, where, and how you work. Each project includes an online workspace shared by you and your client, allowing you to:</h4>
                                        <p class="text-muted"></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 box8">
                            <h4>Get paid on time</h4>
                                        <h4 class="subheading">All projects include GetLance Payment Protection — helping ensure that you get paid for all work successfully completed through the freelancing website.</h4>
                                        <p class="text-muted"></p>
                        </div>
                        <div class="col-md-6 how-img">
                            <img src={img4} class="rounded-circle img-fluid" alt=""/>
                        </div>
                    </div>
                </div>

                </div>





























/* 
        <div class="container mt-40" style={{fontFamily:"monospace", textAlign:"center", fontSize: "15px", fontWeight: "lighter"}}>

            <div class="row mt-40">
                <div class="col-md-3 col-sm-3" >
                    <div class="box8" style={{ padding: "30px"}}>
                        <img src={img1} />
                        <h3 class="title">OXIDANTES</h3>
                        <div class="box-content" style={{ color: "#FFFF", alignItems:"center"}}>
                            <div id='ptg1-texto' style={{position: "relative", }}>
                                <p>Oxidantes</p>
                                <p>Peróxidos orgânicos</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-3" >
                    <div class="box8" style={{ padding: "30px", }}>
                        <img src={img2} />
                        <h3 class="title">INFLAMÁVEIS</h3>
                        <div class="box-content" style={{ color: "#FFFF", }}>
                        <ul class="icon">
                            <div id='ptg2-texto' style={{position: "relative", }}>
                                <p>Inflamáveis</p>
                                <p>Auto reativos</p>
                                <p>Pirofóricos</p>
                                <p>Auto aquecíveis</p>
                                <p>Emite gás inflamável</p>
                            </div>
                        </ul>
                        </div>
                    </div>
                </div>


                <div class="col-md-3 col-sm-3" >
                    <div class="box8" style={{ padding: "30px", }}>
                        <img src={img3} />
                        <h3 class="title">CORROSIVOS</h3>
                        <div class="box-content" style={{ color: "#FFFF", }}>
                            <ul class="icon">
                                <div id='ptg3-texto' style={{position: "relative", fontSize: "20px"}}>
                                    <p>Corrosivos</p>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3" >
                    <div class="box8" style={{ padding: "30px", }}>
                        <img src={img4} />
                        <h3 class="title">IRRITANTE</h3>
                        <div class="box-content" style={{ color: "#FFFF", }}>
                            <ul class="icon">
                                <div id='ptg4-texto' style={{position: "relative", }}>
                                    <p>Irritante</p>
                                    <p>Sensibilizante dérmico</p>
                                    <p>Toxicidade aguda (perigoso)</p>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row mt-30" >
                    <div class="col-md-3 col-sm-3" >
                        <div class="box8" style={{ padding: "30px", }}>
                            <img src={img5} />
                            <h3 class="title">PERIGO AO MEIO AMBIENTE</h3>
                            <div class="box-content" style={{ color: "#FFFF", }}>
                                <div id='ptg1-texto' style={{position: "relative", }}>
                                    <div id='ptg5-texto'>
                                        <p>Perigo ao Meio Ambiente</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-3" >
                        <div class="box8" style={{ padding: "30px", }}>
                            <img src={img6} />
                            <h3 class="title">CARCINOGÊNICO</h3>
                            <div class="box-content" style={{ color: "#FFFF", }}>
                                <div id='ptg6-texto' style={{position: "relative", }}>
                                    <p>Carcinogênico</p>
                                    <p>Toxicidade a reprodução</p>
                                    <p>Toxicidade a órgão alvo</p>
                                    <p>Mutagenicidade</p>
                                    <p>Sensibilizante à respiração</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-3 col-sm-3" >
                        <div class="box8" style={{ padding: "30px", }}>
                            <img src={img7} />
                            <h3 class="title">TOXICIDADE AGUDA</h3>
                            <div class="box-content" style={{ color: "#FFFF", }}>
                                <div id='ptg7-texto' style={{position: "relative", }}>
                                    <p>Toxicidade aguda (severa)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-3" style={{ padding: "30px", }} >
                        <div class="box8">
                            <img src={img8} />
                            <h3 class="title">EXPLOSIVOS</h3>
                            <div class="box-content" style={{ color: "#FFFF", }}>
                                <div id='ptg8-texto' style={{position: "relative", }}>
                                    <p>Explosivos</p>
                                    <p>Auto-reagentes</p>
                                    <p>Peróxidos Orgânicos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div > */
    )
};